`timescale 1ns / 1ps

module I2C_Master (
    input  logic       clk,
    input  logic       rst,
    // command port
    input  logic       cmd_start,  // trigger start
    input  logic       cmd_write,
    input  logic       cmd_read,
    input  logic       cmd_stop,
    input  logic [7:0] tx_data,     // 외부에서 받는값 -> slave한테 쪼개서 줌
    input  logic       ack_in,     // 마스터가 받는거
    // internal output
    output logic [7:0] rx_data,     // slave 한테 받은값 내보냄 -> 외부한테
    output logic       done,
    output logic       ack_out,    // master가 주는거
    output logic       busy,
    // external i2c port
    output logic       scl,
    inout  logic       sda
);

    logic sda_o, sda_i;


    assign sda_i = sda;
    assign sda   = sda_o ? 1'bz : 1'b0;


    i2c_master u_12c_master (
        .*,
        .sda_o(sda_o),
        .sda_i(sda_i)
    );

endmodule










module i2c_master (
    input  logic       clk,
    input  logic       rst,
    // command port
    input  logic       cmd_start,  // trigger start
    input  logic       cmd_write,
    input  logic       cmd_read,
    input  logic       cmd_stop,
    input  logic [7:0] tx_data,
    input  logic       ack_in,     // 마스터가 받는거
    // internal output
    output logic [7:0] rx_data,
    output logic       done,
    output logic       ack_out,    // master가 주는거
    output logic       busy,
    // external i2c port
    output logic       scl,
    output logic       sda_o,
    input  logic       sda_i
);


    typedef enum logic [2:0] {
        IDLE,
        START,
        WAIT_CMD,
        DATA,
        DATA_ACK,
        STOP
    } i2c_state_e;

    i2c_state_e       state;

    // tickgen
    logic       [7:0] div_cnt;
    logic             qtr_tick;

    // register
    logic scl_r, sda_r;
    logic [1:0] step;

    // register
    logic [7:0] tx_shift_reg, rx_shift_reg;
    logic [2:0] bit_cnt;
    logic is_read, ack_in_r;

    //connect
    assign scl   = scl_r;
    assign sda_o = sda_r;

    assign busy  = (state != IDLE);



    // tickgen
    always_ff @(posedge clk, posedge rst) begin
        if (rst) begin
            div_cnt  <= 0;
            qtr_tick <= 0;
        end else begin
            if (div_cnt == 250 - 1) begin  // scl : 100khz
                div_cnt  <= 0;
                qtr_tick <= 1'b1;
            end else begin
                qtr_tick <= 1'b0;
                div_cnt  <= div_cnt + 1;
            end
        end
    end

    // assign qtr_tick = (div_cnt == 250 - 1);

    always_ff @(posedge clk, posedge rst) begin 
        if (rst) begin
            state        <= IDLE;
            scl_r        <= 1'b1;
            sda_r        <= 1'b1;
            // busy         <= 1'b0;
            step         <= 1'b0;
            done         <= 1'b0;
            tx_shift_reg <= 8'h0;
            rx_shift_reg <= 8'h0;
            bit_cnt      <= 3'd0;
            ack_in_r     <= 1'b1;  // nack 상태로 전송
            is_read      <= 1'b0;
        end else begin
            done <= 1'b0;
            case (state)
                IDLE: begin
                    scl_r <= 1'b1;
                    sda_r <= 1'b1;
                    busy  <= 1'b0;
                    if (cmd_start) begin
                        state <= START;
                        step  <= 0;
                        // busy  <= 1'b1;
                    end
                end
                START: begin
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                scl_r <= 1'b1;
                                sda_r <= 1'b1;
                                step  <= 2'd1;
                            end
                            2'd1: begin
                                sda_r <= 1'b0;
                                step  <= 2'd2;
                            end
                            2'd2: begin
                                step <= 2'd3;
                            end
                            2'd3: begin
                                scl_r <= 1'b0;
                                step  <= 2'd0;
                                done  <= 1'b1;
                                state <= WAIT_CMD;
                            end
                        endcase
                    end
                end
                WAIT_CMD: begin
                    step <= 0;
                    if (cmd_write) begin
                        tx_shift_reg <= tx_data;
                        bit_cnt <= 0;
                        is_read <= 1'b0;
                        state <= DATA;
                    end else if (cmd_read) begin
                        rx_shift_reg <= 0;
                        bit_cnt <= 0;
                        is_read <= 1'b1;
                        ack_in_r <= ack_in;
                        state <= DATA;
                    end else if (cmd_stop) begin
                        state <= STOP;
                    end else if (cmd_start) begin
                        state <= START;
                    end
                end
                DATA: begin
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                scl_r <= 1'b0;
                                sda_r <= is_read ? 1'b1 : tx_shift_reg[7];  // msb, no read -> send
                                step <= 2'd1;
                            end
                            2'd1: begin
                                scl_r <= 1'b1;
                                step  <= 2'd2;
                            end
                            2'd2: begin
                                scl_r <= 1'b1;
                                if (is_read) begin
                                    rx_shift_reg <= {rx_shift_reg[6:0], sda_i};
                                end // read
                                step <= 2'd3;
                            end
                            2'd3: begin
                                scl_r <= 1'b0;
                                if (!is_read) begin
                                    tx_shift_reg <= {
                                        tx_shift_reg[6:0], 1'b0
                                    };  // msb
                                end    // write
                                step <= 2'd0;

                                if (bit_cnt == 7) begin
                                    state <= DATA_ACK;

                                end else begin
                                    bit_cnt <= bit_cnt + 1;
                                end
                            end
                        endcase
                    end
                end
                DATA_ACK: begin
                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                scl_r <= 1'b0;
                                if (is_read) begin
                                    sda_r <= ack_in_r;
                                end else begin
                                    sda_r <= 1'b1;  // sda input setting
                                end
                                step <= 2'd1;
                            end
                            2'd1: begin
                                scl_r <= 1'b1;
                                step  <= 2'd2;

                            end
                            2'd2: begin
                                scl_r <= 1'b1;
                                if (!is_read) begin  // ack 수신
                                    ack_out <= sda_i;
                                end
                                if (is_read) begin
                                    rx_data <= rx_shift_reg;
                                end

                                step <= 2'd3;
                            end
                            2'd3: begin
                                scl_r <= 1'b0;
                                done  <= 1'b1;
                                step  <= 2'd0;
                                state <= WAIT_CMD;
                            end
                        endcase
                    end
                end
                STOP: begin

                    if (qtr_tick) begin
                        case (step)
                            2'd0: begin
                                scl_r <= 1'b0;
                                sda_r <= 1'b0;
                                step  <= 2'd1;
                            end
                            2'd1: begin
                                scl_r <= 1'b1;
                                step  <= 2'd2;

                            end
                            2'd2: begin
                                sda_r <= 1'b1;
                                step  <= 2'd3;
                            end
                            2'd3: begin
                                step  <= 2'd0;
                                done  <= 1'b1;
                                state <= IDLE;
                            end


                            default: begin
                                state <= IDLE;
                            end


                        endcase
                    end
                end
            endcase
        end
    end

endmodule
