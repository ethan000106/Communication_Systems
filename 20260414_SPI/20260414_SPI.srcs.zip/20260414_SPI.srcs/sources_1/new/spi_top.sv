`timescale 1ns / 1ps

module spi_top (
    input logic clk,
    input logic rst,
    input logic cpol,  // idle 0 : low , 1: high
    input logic cpha,  // first sampling, 0 : first edge, 1 : second edge
    input logic [7:0] clk_div,
    input logic [7:0] tx_data,
    input logic start,
    output logic [7:0] rx_data,
    output logic done,
    output logic busy,
    output logic sclk,
    output logic mosi,
    output logic miso,
    output logic cs_n
);
endmodule



