`timescale 1ns / 1ps
module spi_master (
    input logic clk,
    input logic rst,
    input logic cpol,  // idle 0 : low , 1: high
    input logic cpha,  // first sampling, 0 : first edge, 1 : second edge
    input logic [7:0] clk_div,
    input logic [7:0] tx_data,
    input logic start,
    output logic [7:0] rx_data,
    output logic done,
    output logic busy,
    output logic sclk,
    output logic mosi,
    output logic miso,
    output logic cs_n
);



    typedef enum logic [1:0] {
        IDLE,
        START,
        DATA,
        STOP
    } spi_state_e;

    spi_state_e state;
    logic [7:0] div_cnt, tx_shift_reg, rx_shift_reg;
    logic [2:0] bit_cnt;
    logic half_tick, step, sclk_r;

    assign sclk = sclk_r;
    // logic 이 assign 으로 하면 바로 포트로 내보내짐 

    // tick gen
    always_ff @(posedge clk, posedge rst) begin
        if (rst) begin
            div_cnt   <= 0;
            half_tick <= 1'b0;
        end else begin
            if (state == DATA) begin
                if (div_cnt == clk_div) begin
                    div_cnt   <= 0;
                    half_tick <= 1'b1;
                end else begin
                    div_cnt   <= div_cnt + 1;
                    half_tick <= 1'b0;
                end
            end
        end
    end

    // state fsm
    always_ff @(posedge clk, posedge rst) begin
        if (rst) begin
            state <= IDLE;
            mosi <= 1'bz;
            cs_n <= 1'b1;
            busy <= 1'b0;
            done <= 1'b0;
            tx_shift_reg <= 8'h0;
            rx_shift_reg <= 8'h0;
            bit_cnt <= 1'b0;
            step <= 1'b0;
            rx_data <= 8'h0;
            sclk_r <= cpol;
        end else begin
            done <= 1'b0;
            case (state)
                IDLE: begin
                    mosi <= 1'bz;
                    cs_n <= 1'b1;  // 0일때 select
                    // sclk_r <= 1'b0;  // polarity 가 0이라서
                    sclk_r <= cpol;  // cpol 에 맞춰서 토글이 되니까 다른것은 설정 안해도 된다.
                    if (start) begin
                        tx_shift_reg <= tx_data;
                        bit_cnt      <= 0;
                        step         <= 1'b0;
                        busy         <= 1'b1;
                        cs_n         <= 1'b0;  // 0으로 해서 select확인
                        state        <= START;
                    end
                end

                START: begin
                    if (!cpha) begin
                        mosi <= tx_shift_reg[7];   // msb (master는 msb부터 보냄)
                        tx_shift_reg <= {tx_shift_reg[6:0], 1'b0};
                    end
                    state <= DATA;
                end


                DATA: begin
                    if (half_tick) begin
                        sclk_r <= ~sclk_r;  // clk toggle
                        if (step == 0) begin  // soo sin gu gan
                            step <= 1'b1;
                            if (!cpha) begin
                                rx_shift_reg <= {rx_shift_reg[6:0], miso};
                            end else begin
                                mosi <= tx_shift_reg[7];
                                tx_shift_reg <= {tx_shift_reg[6:0], 1'b0};
                            end
                        end else begin  // song sin gu gan
                            step <= 1'b0;
                            if (!cpha) begin
                                if (bit_cnt < 7) begin
                                    mosi <= tx_shift_reg[7];
                                    tx_shift_reg <= {tx_shift_reg[6:0], 1'b0};
                                end
                            end else begin
                                rx_shift_reg <= {rx_shift_reg[6:0], miso};
                            end
                            if (bit_cnt == 7) begin
                                state <= STOP;
                                if (!cpha) begin
                                    rx_data <= rx_shift_reg;
                                end else begin
                                    // rx_data <= rx_shift_reg;
                                    rx_data <= {rx_shift_reg[6:0], miso};
                                end
                            end else begin
                                bit_cnt <= bit_cnt + 1;
                            end
                        end
                    end

                end


                STOP: begin
                    sclk_r <= 1'b0;
                    cs_n   <= 1'b1;
                    done   <= 1'b1;
                    busy   <= 1'b0;
                    mosi   <= 1'bz;
                    state  <= IDLE;
                end
                default: begin
                    state <= IDLE;
                end
            endcase
        end
    end

endmodule
